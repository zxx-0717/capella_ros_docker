#include "welt_model/welt_model_node.h"

using namespace std::placeholders;
using namespace std::chrono_literals;

WeltModelNode::WeltModelNode()
{
    node_ = std::make_shared<rclcpp::Node>("welt_model_node");
    tf_ = std::make_shared<tf2_ros::Buffer>(node_->get_clock());
    transform_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_);
    costmap_sub_ = std::make_shared<nav2_costmap_2d::CostmapSubscriber>(node_, "/local_costmap/costmap_raw");
    footprint_sub_ = std::make_shared<nav2_costmap_2d::FootprintSubscriber>(node_, "/global_costmap/published_footprint", *tf_, "base_link");
    rclcpp::QoS qos(rclcpp::KeepLast(10));
    cmd_vel_pub_ = node_->create_publisher<geometry_msgs::msg::Twist>("cmd_vel", 1);
    
    welt_model_server_ = rclcpp_action::create_server<capella_ros_msg::action::Welt>(
        node_->get_node_base_interface(),
        node_->get_node_clock_interface(),
        node_->get_node_logging_interface(),
        node_->get_node_waitables_interface(),
        "welt_model_node",
        std::bind(&WeltModelNode::hand_goal, this, _1, _2),
        std::bind(&WeltModelNode::cancel_goal, this, _1),
        std::bind(&WeltModelNode::handle_accepted, this, _1));

    node_->declare_parameter("width_threshold", 0.0);
    node_->declare_parameter("back_threshold", 0.2);
    node_->get_parameter("width_threshold", width_threshold);
    node_->get_parameter("back_threshold", back_threshold);
    dyn_params_handler_ = node_->add_on_set_parameters_callback(std::bind(&WeltModelNode::dynamicParametersCallback, this, std::placeholders::_1));
    // state_timer_ = node_->create_wall_timer(100ms, [this]() { stateMachine(); });
}

rclcpp_action::GoalResponse WeltModelNode::hand_goal(const rclcpp_action::GoalUUID &uuid,
    std::shared_ptr<const capella_ros_msg::action::Welt::Goal> goal)
{
return rclcpp_action::GoalResponse::ACCEPT_AND_EXECUTE; 
}

rclcpp_action::CancelResponse WeltModelNode::cancel_goal(const std::shared_ptr<rclcpp_action::ServerGoalHandle<capella_ros_msg::action::Welt>> goal_handle)
{
return rclcpp_action::CancelResponse::ACCEPT;
}

void WeltModelNode::handle_accepted(const std::shared_ptr<rclcpp_action::ServerGoalHandle<capella_ros_msg::action::Welt>> goal_handle)
{
auto future = std::async(std::launch::async, &WeltModelNode::execute, this, goal_handle);
}

void WeltModelNode::execute(const std::shared_ptr<rclcpp_action::ServerGoalHandle<capella_ros_msg::action::Welt>> goal_handle)
{
    auto result = std::make_shared<capella_ros_msg::action::Welt::Result>();
    // const auto goal = goal_handle->get_goal();
    std::vector<geometry_msgs::msg::Point> footprint;
    std_msgs::msg::Header header;
    if(footprint_sub_->getFootprintInRobotFrame(footprint, header)){
        footprint_h_front = std::max(fabs(footprint[0].x), fabs(footprint[2].x));
        footprint_h_back = std::min(fabs(footprint[0].x), fabs(footprint[2].x));
        footprint_w = fabs(footprint[0].y);
        RCLCPP_INFO(rclcpp::get_logger("welt_test"), "footprint param:%f,%f,%f",footprint_h_front,footprint_h_back,footprint_w);
    }
    else{
        RCLCPP_ERROR(rclcpp::get_logger("robot_avoidance"), "Failed to get robot footprint");
        goal_handle->abort(result);
    }
    goal_pose_ = goal_handle->get_goal()->goal_pose;
    if(goal_pose_.pose.position.z == 10.0){
        goal_handle->abort(result);
    }
    walt_start_pose_theta = tf2::getYaw(goal_pose_.pose.orientation);
    RCLCPP_INFO(rclcpp::get_logger("welt_test"), "posecallback theta:%f,%f,%f",goal_pose_.pose.position.x,goal_pose_.pose.position.y,walt_start_pose_theta);
    
    try {
        geometry_msgs::msg::Pose2D robot_pose = getrobotpose();
        welt_to_robot_theta = std::atan2(robot_pose.y - goal_pose_.pose.position.y, 
                                        robot_pose.x - goal_pose_.pose.position.x);
        
        // 重置状态机
        // current_state_ = ControlState::ROTATING_TO_GOAL;
        RCLCPP_INFO(rclcpp::get_logger("welt_test"), "Starting control sequence");
    } catch (const std::exception& e) {
        RCLCPP_ERROR(rclcpp::get_logger("welt_test"), "Error in pose callback: %s", e.what());
    }
    if(!stateMachine()){
        goal_handle->abort(result);
    }

    if (rclcpp::ok()) {
        goal_handle->succeed(result);
    }
}

std::vector<geometry_msgs::msg::Point> WeltModelNode::getAllEdgePoints() {
    // 获取footprint四个顶点
    std::vector<geometry_msgs::msg::Point> new_footprint;
    const int num_points = 4; 
    const double xs[num_points] = {footprint_h_front, footprint_h_front, -footprint_h_back, -footprint_h_back};
    const double ys[num_points] = {footprint_w, -footprint_w, -footprint_w, footprint_w};
    for (int i = 0; i < num_points; ++i) {
        geometry_msgs::msg::Point point;
        point.x = xs[i];
        point.y = ys[i];
        new_footprint.push_back(point);
    }
    // 计算四个顶点构成的四条边上的所有点
    std::vector<geometry_msgs::msg::Point> edge_points;
    for (size_t i = 0; i < new_footprint.size(); ++i) {
        geometry_msgs::msg::Point start = new_footprint[i];
        geometry_msgs::msg::Point end = new_footprint[(i + 1) % new_footprint.size()];
        double dx = end.x - start.x;
        double dy = end.y - start.y;
        double distance = std::sqrt(dx * dx + dy * dy);
        int num_points = static_cast<int>(distance / 0.05) + 1;
        for (int j = 0; j < num_points; ++j) {
            geometry_msgs::msg::Point point;
            point.x = start.x + j * 0.05 * dx / distance;
            point.y = start.y + j * 0.05 * dy / distance;
            edge_points.push_back(point);
        }
    }
    return edge_points;
}

bool WeltModelNode::check_rotation_is_reliable(double rotation_sign){
    try
    {
        geometry_msgs::msg::Pose2D robot_pose = getrobotpose();
        double robot_x = robot_pose.x;
        double robot_y = robot_pose.y;
        std::vector<geometry_msgs::msg::Point> edge_points = getAllEdgePoints();
        auto costmap_get = costmap_sub_->getCostmap();
        for(double t = 0.05; t < 0.21; t += 0.05){
            double cos_th = cos(robot_pose.theta + t * rotation_sign);
            double sin_th = sin(robot_pose.theta + t * rotation_sign);
            for(size_t i = 0; i < edge_points.size(); i++){
                unsigned int map_x,map_y;
                double g_x = robot_x + edge_points[i].x * cos_th - edge_points[i].y * sin_th;
                double g_y = robot_y + edge_points[i].x * sin_th + edge_points[i].y * cos_th;
                if(costmap_get->worldToMap(g_x, g_y, map_x, map_y) && costmap_get->getCost(map_x, map_y) >= 254){
                    RCLCPP_INFO(rclcpp::get_logger("welt_test"), "旋转有碰撞风险");
                    return false;
                }
            }
        }
        return true;
    }
    catch(const std::exception& e)
    {
        RCLCPP_ERROR(rclcpp::get_logger("welt_test"), "Error in get robot while check rotation: %s", e.what());
        return false;
    }
}

bool WeltModelNode::check_back_is_reliable(){
    try
    {
        geometry_msgs::msg::Pose2D robot_pose = getrobotpose();
        // check collision
        double robot_x = robot_pose.x;
        double robot_y = robot_pose.y;
        double cos_th = cos(robot_pose.theta);
        double sin_th = sin(robot_pose.theta);
        // check distance
        double current_distance = sqrt(pow(goal_pose_.pose.position.x - robot_pose.x, 2) + pow(goal_pose_.pose.position.y - robot_pose.y, 2));
        double pre_robot_x = robot_x - 0.2 * cos_th;
        double pre_robot_y = robot_y - 0.2 * sin_th;
        double pre_distance = sqrt(pow(goal_pose_.pose.position.x - pre_robot_x, 2) + pow(goal_pose_.pose.position.y - pre_robot_y, 2));
        if(current_distance <= 0.5 || pre_distance >= current_distance){
            RCLCPP_INFO(rclcpp::get_logger("welt_test"), "到达目标点附近");
            return true;
        }
        // RCLCPP_INFO(rclcpp::get_logger("welt_test"), "dis > 0.5");
        auto costmap_get = costmap_sub_->getCostmap();
        for (double x = -footprint_h_back - back_threshold; x <= -footprint_h_back + back_threshold; x += 0.05){
            for (double y = -footprint_w - width_threshold; y < footprint_w + width_threshold; y += 0.1){
                unsigned int map_x,map_y;
                double g_x = robot_x + x * cos_th - y * sin_th;
                double g_y = robot_y + x * sin_th + y * cos_th;
                if(costmap_get->worldToMap(g_x, g_y, map_x, map_y) && costmap_get->getCost(map_x, map_y) >= 254){
                    RCLCPP_INFO(rclcpp::get_logger("welt_test"), "后退有障碍物");
                    return false; 
                }
            }
        }
        return true;
    }
    catch(const std::exception& e)
    {
        RCLCPP_ERROR(rclcpp::get_logger("welt_test"), "Error in get robot while check back: %s", e.what());
        return false;
    }
}

double WeltModelNode::compute_angular_direction(double goal, double robot)
{
    double difference = goal - robot;
    if (difference < -M_PI) {
      difference = 2 * M_PI + difference;
    } 
    if (difference > M_PI) {  
      difference = -2 * M_PI + difference;  
    } 
    return difference;
}

geometry_msgs::msg::Pose2D WeltModelNode::getrobotpose()
{
    geometry_msgs::msg::PoseStamped pose;
    if (!nav2_util::getCurrentPose(pose, *tf_, "map", "base_link")) {
        RCLCPP_ERROR(rclcpp::get_logger("welt_test"), "Failed to get robot pose!");
        throw std::runtime_error("Failed to get robot pose");
    }
    geometry_msgs::msg::Pose2D robot_pose;
    robot_pose.x = pose.pose.position.x;    
    robot_pose.y = pose.pose.position.y;
    robot_pose.theta = tf2::getYaw(pose.pose.orientation);
    // RCLCPP_INFO(rclcpp::get_logger("welt_test"), "robot_pose: %f, %f, %f, %f****:%f",pose.pose.orientation.x,pose.pose.orientation.y,pose.pose.orientation.z,pose.pose.orientation.w,robot_pose.theta);
    return robot_pose;
}

bool WeltModelNode::back_to_approach_goal()
{
    try
    {
        geometry_msgs::msg::Pose2D robot_pose = getrobotpose();
        double robot_x = robot_pose.x;
        double robot_y = robot_pose.y;
        double cos_th = cos(robot_pose.theta);
        double sin_th = sin(robot_pose.theta);
        // check distance
        double current_distance = sqrt(pow(goal_pose_.pose.position.x - robot_x, 2) + pow(goal_pose_.pose.position.y - robot_y, 2));
        double pre_robot_x = robot_x - 0.2 * cos_th;
        double pre_robot_y = robot_y - 0.2 * sin_th;
        double pre_distance = sqrt(pow(goal_pose_.pose.position.x - pre_robot_x, 2) + pow(goal_pose_.pose.position.y - pre_robot_y, 2));
        
        if(current_distance > 0.5 && pre_distance < current_distance){
            // RCLCPP_INFO(rclcpp::get_logger("welt_test"), "**** back ****");
            return false;
        }
        return true;
    }
    catch(const std::exception& e)
    {
        RCLCPP_ERROR(rclcpp::get_logger("welt_test"), "Error in get robot while back to goal: %s", e.what());
        // return true;
    }
    
}

// check robot is rotate to goal direction
bool WeltModelNode::is_rotation_to_included_angle(double rotate_angular){
    try
    {
        geometry_msgs::msg::Pose2D robot_pose = getrobotpose();
        double difference = compute_angular_direction(rotate_angular, robot_pose.theta);
        
        if(fabs(difference) < 0.05){
            return true;
        }
        return false;
    }
    catch(const std::exception& e)
    {
        RCLCPP_ERROR(rclcpp::get_logger("welt_test"), "Error in is_rotation_to_included_angle: %s", e.what());
        // throw
        // return true;
    }
    
}

rcl_interfaces::msg::SetParametersResult WeltModelNode::dynamicParametersCallback(std::vector<rclcpp::Parameter> parameters){
    rcl_interfaces::msg::SetParametersResult result;

    for (auto parameter : parameters) {
        const auto & type = parameter.get_type();
        const auto & name = parameter.get_name();

        if (type == ParameterType::PARAMETER_DOUBLE) {
          if (name == "width_threshold") {
            width_threshold = parameter.as_double();
          } 
          else if (name == "back_threshold") {
            back_threshold = parameter.as_double();
          } 
        }
    }

    result.successful = true;
    return result;
}

  void WeltModelNode::run()
{
    rclcpp::spin(node_);
}

int main(int argc, char** argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<WeltModelNode>();
    // rclcpp::spin(node);  
    node->run();
    rclcpp::shutdown();
    return 0;
}