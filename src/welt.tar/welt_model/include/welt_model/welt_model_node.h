#include "rclcpp/rclcpp.hpp"
#include "nav2_costmap_2d/costmap_2d_ros.hpp"
#include "nav2_costmap_2d/costmap_subscriber.hpp"
#include "nav2_costmap_2d/footprint_subscriber.hpp"
#include "nav2_costmap_2d/costmap_topic_collision_checker.hpp"
#include "nav2_util/lifecycle_node.hpp"
#include "nav_msgs/msg/path.hpp"
#include "nav2_util/geometry_utils.hpp"
#include "nav2_util/robot_utils.hpp"
#include "nav2_util/node_utils.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "tf2_ros/transform_listener.h"
#include "nav2_costmap_2d/exceptions.hpp"
#include "std_msgs/msg/bool.hpp"
#include "capella_ros_msg/action/welt.hpp"
#include "rclcpp_action/rclcpp_action.hpp"

#include <functional>
#include <memory>
#include <thread>
#include "rclcpp_components/register_node_macro.hpp"
#include "std_msgs/msg/float32.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "nav_msgs/msg/occupancy_grid.hpp"
#include "tf2_ros/buffer.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.hpp"
#include <deque>
#include "rcl_interfaces/msg/set_parameters_result.hpp"
using rcl_interfaces::msg::ParameterType;
using std::placeholders::_1;

enum class ControlState {
    IDLE,
    ROTATING_TO_GOAL,
    BACKING_TO_GOAL,
    FINAL_ROTATION
};
class WeltModelNode
{
        public:
                WeltModelNode();
                void backupAndRotate();
                std::vector<geometry_msgs::msg::Point> getAllEdgePoints();
                bool check_rotation_is_reliable(double rotation_sign);
                bool check_back_is_reliable();
                bool rotation_to_back();
                double compute_angular_direction(double goal, double robot);
                geometry_msgs::msg::Pose2D getrobotpose();
                bool back_to_approach_goal();
                bool is_rotation_to_included_angle(double rotate_angular);
                void run();
                void stopProcessingMessages();
                rclcpp::Node::SharedPtr get_node() const {
                        return node_;
                }
        protected:
                rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr dyn_params_handler_;
                rcl_interfaces::msg::SetParametersResult dynamicParametersCallback(std::vector<rclcpp::Parameter> parameters);
        private: 
                rclcpp_action::Server<capella_ros_msg::action::Welt>::SharedPtr welt_model_server_;
                rclcpp_action::GoalResponse hand_goal(const rclcpp_action::GoalUUID &uuid,
                                                std::shared_ptr<const capella_ros_msg::action::Welt::Goal> goal);
                rclcpp_action::CancelResponse cancel_goal(const std::shared_ptr<rclcpp_action::ServerGoalHandle<capella_ros_msg::action::Welt>> goal_handle);
                void handle_accepted(const std::shared_ptr<rclcpp_action::ServerGoalHandle<capella_ros_msg::action::Welt>> goal_handle);
                void execute(const std::shared_ptr<rclcpp_action::ServerGoalHandle<capella_ros_msg::action::Welt>> goal_handle);

                std::shared_ptr<nav2_costmap_2d::CostmapSubscriber> costmap_sub_;
                std::shared_ptr<nav2_costmap_2d::FootprintSubscriber> footprint_sub_;
                std::shared_ptr<tf2_ros::Buffer> tf_;
                std::shared_ptr<tf2_ros::TransformListener> transform_listener_;
                std::shared_ptr<rclcpp::Node> node_;
                geometry_msgs::msg::PoseStamped goal_pose_;
                rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_pub_;
                double walt_start_pose_theta;
                double footprint_w, footprint_h_back, footprint_h_front;
                double back_threshold, width_threshold;
                // double rotation_sign_ = 0.0;
                bool update = false;
                bool is_update_reverse = false;
                rclcpp::Time start_time_;
                double welt_to_robot_theta;
                bool operation_enabled_;
                rclcpp::Time last_operation_time_;
                ControlState current_state_ = ControlState::IDLE;
                bool reached_goal(){
                        try {
                                geometry_msgs::msg::Pose2D robot_pose = getrobotpose();
                                double distance = sqrt(pow(goal_pose_.pose.position.x - robot_pose.x, 2) + pow(goal_pose_.pose.position.y - robot_pose.y, 2));
                                return distance < 0.5;
                        }
                        catch (const std::exception& e) {
                                RCLCPP_ERROR(rclcpp::get_logger("welt_test"), "Error in reached_goal: %s", e.what());
                        }
                }
                bool stateMachine() {
                        if(!reached_goal()){
                                if(!handleRotationToGoal()){
                                        return false;
                                }
                                if(!handleBackingToGoal()){
                                        return false;
                                }
                        }
                        if(!handleFinalRotation()){
                                return false;
                        }
                        return true; 
                }
                
                bool handleRotationToGoal() {
                        rclcpp::Clock steady_clock_{RCL_STEADY_TIME};
                        double start_time_= steady_clock_.now().seconds();
                        bool update_action = false;
                        RCLCPP_INFO(rclcpp::get_logger("welt_test"), "进入第一次旋转程序");
                        if(!is_rotation_to_included_angle(welt_to_robot_theta)){
                                RCLCPP_INFO(rclcpp::get_logger("welt_test"), "开始第一次旋转");
                                update_action = true;
                        }
                        while(update_action){
                                try {
                                        if(steady_clock_.now().seconds() - start_time_ > 30.0){
                                                RCLCPP_INFO(rclcpp::get_logger("welt_test"), "第一次旋转程序超时");
                                                return false;
                                        }
                                        geometry_msgs::msg::Pose2D robot_pose = getrobotpose();
                                        // RCLCPP_INFO(rclcpp::get_logger("welt_test"), "robot_pose.theta in first rotate");
                                        double difference = compute_angular_direction(welt_to_robot_theta, robot_pose.theta);
                                        double rotation_sign = difference > 0 ? 1.0 : -1.0;
                                
                                        if (std::abs(difference) < 0.05) {
                                                // current_state_ = ControlState::BACKING_TO_GOAL;
                                                RCLCPP_INFO(rclcpp::get_logger("welt_test"), "完成并退出第一次旋转");
                                                publishStopCommand();
                                                return true;
                                        }
                                
                                        geometry_msgs::msg::Twist cmd_vel;
                                        cmd_vel.linear.x = 0;
                                        cmd_vel.angular.z = check_rotation_is_reliable(rotation_sign) ? 0.2 * rotation_sign : 0;
                                        // RCLCPP_INFO(rclcpp::get_logger("welt_test"), "robot_pose.theta in first rotate: %f", cmd_vel.angular.z);
                                        cmd_vel_pub_->publish(cmd_vel);
                        
                                } catch (const std::exception& e) {
                                        RCLCPP_ERROR(rclcpp::get_logger("welt_test"), "Error in rotation to goal: %s", e.what());
                                // current_state_ = ControlState::IDLE;
                                }
                        }
                        RCLCPP_INFO(rclcpp::get_logger("welt_test"), "本身方向一致，不需要旋转，退出第一次旋转程序");
                        return true;
                }
                
                bool handleBackingToGoal() {
                        rclcpp::Clock steady_clock_{RCL_STEADY_TIME};
                        double start_time_= steady_clock_.now().seconds();
                        RCLCPP_INFO(rclcpp::get_logger("welt_test"), "进入后退程序");
                        try {
                                while (!back_to_approach_goal()) {
                                        if(steady_clock_.now().seconds() - start_time_ > 30.0){
                                                RCLCPP_INFO(rclcpp::get_logger("welt_test"), "后退程序超时");
                                                return false;
                                        }
                                        geometry_msgs::msg::Twist cmd_vel;
                                        cmd_vel.linear.x = check_back_is_reliable() ? -0.2 : 0;
                                        cmd_vel.angular.z = 0;
                                        cmd_vel_pub_->publish(cmd_vel);
                                }
                                // current_state_ = ControlState::FINAL_ROTATION;
                                RCLCPP_INFO(rclcpp::get_logger("welt_test"), "完成并推出后退程序");
                                publishStopCommand();
                                return true;
                                // break;
                        } catch (const std::exception& e) {
                        RCLCPP_ERROR(rclcpp::get_logger("welt_test"), "Error in backing to goal: %s", e.what());
                        // current_state_ = ControlState::IDLE;
                        }
                }
                
                bool handleFinalRotation() {
                        rclcpp::Clock steady_clock_{RCL_STEADY_TIME};
                        double start_time_= steady_clock_.now().seconds();
                        RCLCPP_INFO(rclcpp::get_logger("welt_test"), "进入最后旋转程序");
                        bool update_action = false;
                        if(!is_rotation_to_included_angle(walt_start_pose_theta)){
                                RCLCPP_INFO(rclcpp::get_logger("welt_test"), "开始最后旋转程序");
                                update_action = true;
                        }
                        while(update_action){
                                try {
                                        if(steady_clock_.now().seconds() - start_time_ > 30.0){
                                                RCLCPP_INFO(rclcpp::get_logger("welt_test"), "最后旋转程序超时");
                                                return false;
                                        }
                                        geometry_msgs::msg::Pose2D robot_pose = getrobotpose();
                                        double difference = compute_angular_direction(walt_start_pose_theta, robot_pose.theta);
                                        double rotation_sign = difference > 0 ? 1.0 : -1.0;
                                        // RCLCPP_INFO(rclcpp::get_logger("welt_test"), "Final rotation completed: %f,%f,%f",walt_start_pose_theta, robot_pose.theta,difference);
                                
                                        if (std::abs(difference) < 0.05) {
                                                // current_state_ = ControlState::IDLE;
                                                RCLCPP_INFO(rclcpp::get_logger("welt_test"), "完成并退出最后旋转程序");
                                                publishStopCommand();
                                                return true;
                                        }
                                
                                        geometry_msgs::msg::Twist cmd_vel;
                                        cmd_vel.linear.x = 0;
                                        cmd_vel.angular.z = check_rotation_is_reliable(rotation_sign) ? 0.2 * rotation_sign : 0;
                                        cmd_vel_pub_->publish(cmd_vel);
                        
                                } catch (const std::exception& e) {
                                RCLCPP_ERROR(rclcpp::get_logger("welt_test"), "Error in final rotation: %s", e.what());
                                // current_state_ = ControlState::IDLE;
                                }
                        }
                        RCLCPP_INFO(rclcpp::get_logger("welt_test"), "本身方向一致，退出最后旋转程序");
                        return true;
                }
                
                void publishStopCommand() {
                        geometry_msgs::msg::Twist cmd_vel;
                        cmd_vel.linear.x = 0;
                        cmd_vel.angular.z = 0;
                        cmd_vel_pub_->publish(cmd_vel);
                }
                
                
};